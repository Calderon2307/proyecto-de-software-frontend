export const getRandomIndex = () => {
  return Math.floor(Math.random() * 10);
};
