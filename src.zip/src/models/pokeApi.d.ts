export type PokedexElementApiModel = {
  name: string;
  url: string;
};
