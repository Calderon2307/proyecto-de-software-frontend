export type Ability = {
  name: string;
  effect: string;
  shortEffect: string;
  isHidden: boolean;
};
